import React, { useState } from "react";

function RecipeCreate({ createRecipe }) {
  const initialFormState = {
    name: "",
    cuisine: "",
    photo: "",
    ingredients: "",
    preparation: "",
  };

  const [recipe, setRecipe] = useState(initialFormState);

  const handleChange = ({ target }) => {
    setRecipe({
      ...recipe,
      [target.name]: target.value,
    });
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    createRecipe(recipe);

    // Clear the form after creating the recipe
    setRecipe(initialFormState);
  };

  return (
    <form name="create" onSubmit={handleSubmit}>
      <table>
        <tbody>
          <tr>
            <td>
              <input
                name="name"
                type="text"
                placeholder="Name"
                value={recipe.name}
                onChange={handleChange}
              />
            </td>

            <td>
              <input
                name="cuisine"
                type="text"
                placeholder="Cuisine"
                value={recipe.cuisine}
                onChange={handleChange}
              />
            </td>

            <td>
              <input
                name="photo"
                type="url"
                placeholder="Photo URL"
                value={recipe.photo}
                onChange={handleChange}
              />
            </td>

            <td>
              <textarea
                name="ingredients"
                placeholder="Ingredients"
                value={recipe.ingredients}
                onChange={handleChange}
              />
            </td>

            <td>
              <textarea
                name="preparation"
                placeholder="Preparation"
                value={recipe.preparation}
                onChange={handleChange}
              />
            </td>

            <td>
              <button type="submit">Create</button>
            </td>
          </tr>
        </tbody>
      </table>
    </form>
  );
}

export default RecipeCreate;
