import React, { useState } from "react";
import "./App.css";
import RecipeCreate from "./RecipeCreate";
import RecipeList from "./RecipeList";
import RecipeData from "./RecipeData";

function App() {
  const [recipes, setRecipes] = useState(RecipeData);

  // Delete a recipe from the list
  const deleteRecipe = (indexToDelete) => {
    setRecipes(
      recipes.filter((recipe, index) => index !== indexToDelete)
    );
  };

  // Add a new recipe to the end of the list
  const createRecipe = (newRecipe) => {
    setRecipes([...recipes, newRecipe]);
  };

  return (
    <div className="App">
      <header>
        <h1>Delicious Food Recipes</h1>
      </header>

      <RecipeList
        recipes={recipes}
        deleteRecipe={deleteRecipe}
      />

      <RecipeCreate
        createRecipe={createRecipe}
      />
    </div>
  );
}

export default App;
